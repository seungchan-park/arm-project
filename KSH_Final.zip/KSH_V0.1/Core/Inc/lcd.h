/*
 * lcd.h
 *
 *  Created on: Apr 17, 2024
 *      Author: KCCISTC
 */

#ifndef INC_LCD_H_
#define INC_LCD_H_

#include "stm32f4xx_hal.h"
#include "main.h"

#define PCF8574_ADD		(0x27 << 1)


void I2C_LCD_Command_8bit(unsigned char cmd);
void I2C_LCD_Command(unsigned char cmd);
void I2C_LCD_Data(unsigned char data);
void LCD_string(unsigned char cmd, char *string);
void Initialize_LCD(void);
unsigned char LCD_Busy(void);

#endif /* INC_LCD_H_ */
