/*
 * user.h
 *
 *  Created on: Apr 16, 2024
 *      Author: KCCISTC
 */

#ifndef INC_USER_H_
#define INC_USER_H_

#include <stdio.h>
#include "stm32f4xx_hal.h"
#include "main.h"
#include "lcd.h"

#define C6   	96
#define D6   	85
#define E6   	76
#define F6   	72
#define F6S		68
#define G6   	64
#define A6   	57
#define B6   	51
#define C7   	48

extern unsigned int sec1ms;
extern unsigned int sec2ms;
extern unsigned int sec3ms;

void User_Task1(void);
void MP3_init(void);
void Sound_Flag_Check();

void MP3_sound_control(void);
void MP3_music_control(void);
void MP3_start_stop(void);
void A_music(void);
void B_music(void);
void C_music(void);
void D_music(void);

#endif /* INC_USER_H_ */
