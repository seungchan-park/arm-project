/*
 * lcd.c
 *
 *  Created on: Apr 17, 2024
 *      Author: KCCISTC
 */


#include "lcd.h"

extern I2C_HandleTypeDef hi2c1;

void I2C_LCD_Command_8bit(unsigned char cmd){
	unsigned char bufff[2]={0, };

	bufff[0] = (cmd&0xF0) | 0x04 | 0x08;
	bufff[1] = bufff[0] & (~0x04);

	HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, bufff, 2, 10);
}

void I2C_LCD_Command(unsigned char cmd){	//4bit
	unsigned char bufff[8]={0, };

	LCD_Busy();
	bufff[0] = (cmd&0xF0) | 0x04 | 0x08;
	bufff[1] = 0x08;

	bufff[2] = ((cmd<<4)&0xF0) | 0x04 | 0x08;
	bufff[3] = 0x08;

	HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, bufff, 4, 10);
}

void I2C_LCD_Data(unsigned char data){
	unsigned char bufff[8]={0, };

	LCD_Busy();
	bufff[0] = (data&0xF0) | 0x04 | 0x01 | 0x08;
	bufff[1] = 0x08;

	bufff[2] = ((data<<4)&0xF0) | 0x04 | 0x01 | 0x08;
	bufff[3] = 0x08;

	HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, bufff, 4, 10);
}

void LCD_string(unsigned char cmd, char *string){

	I2C_LCD_Command(cmd);
	while (*string != '\0'){
		I2C_LCD_Data(*string);
		string++;
	}
}

void Initialize_LCD(void){
	//8bit Mode Start
	HAL_Delay(1000);
	I2C_LCD_Command_8bit(0x30);
	HAL_Delay(10);
	I2C_LCD_Command_8bit(0x30);
	HAL_Delay(6);
	I2C_LCD_Command_8bit(0x30);
	I2C_LCD_Command_8bit(0x20); //4bit Mode


	//4bit mode
	I2C_LCD_Command(0x28); //Func 4bit, 2Line, 5*7
	I2C_LCD_Command(0x0C); //Display ON, Curor OFF
	I2C_LCD_Command(0x06); //Entry increment, Not Shift
	I2C_LCD_Command(0x01); //Clear Display
	HAL_Delay(3);
}

unsigned char LCD_Busy(void){
	unsigned char k=0;
	unsigned char T_buf[4];
	unsigned char rxdata=0, rxdata1=0, rxdata2=0;

	T_buf[0] = 0x08 | 0x02;
	T_buf[1] = 0x08 | 0x04 | 0x02;
	T_buf[2] = 0x08 | 0x02;
	for(k=0;k<3;++k){
		HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, &T_buf[0], 2, 10);
		HAL_I2C_Master_Receive(&hi2c1, PCF8574_ADD, &rxdata1, 1, 10);
		HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, &T_buf[2], 1, 10);

		HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, &T_buf[0], 2, 10);
		HAL_I2C_Master_Receive(&hi2c1, PCF8574_ADD, &rxdata2, 1, 10);
		HAL_I2C_Master_Transmit(&hi2c1, PCF8574_ADD, &T_buf[2], 1, 10);

		rxdata=rxdata1;
		rxdata<<=4;
		rxdata|=rxdata2;
		if(!(rxdata&0x80))break;
	}
	return 0;
}
