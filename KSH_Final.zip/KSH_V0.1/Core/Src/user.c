/*
 * user.c
 *
 *  Created on: Apr 16, 2024
 *      Author: KCCISTC
 */
#include "user.h"

extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim3;

unsigned int sec1ms = 0, sec2ms = 0, sec3ms = 0;

// 음악 변경
unsigned int ENC_Value = 0;

// 정지&시작 버튼
unsigned char PA4_INT_Flag = 1;
unsigned char encoder_flag = 0;

// switch debouncing
uint32_t new_tick_1 = 0;
uint32_t old_tick_1 = 0;

// 소리 크기
float sound_value = 0;
unsigned int adc_value[1] = {0};

// 음악 음계
unsigned char a_music[25] = {E6, D6, C6, D6, E6, E6, E6, D6, D6, D6, E6, E6, E6, E6, D6, C6, D6, E6, E6, E6, D6, D6, E6, D6, C6};
unsigned int a_music_term[25] = {1200,450,150,300,300,300,300,600,300,300,600,300,300,600,450,150,300,300,300,300,600,300,300,450,150};
unsigned char b_music[49] = {C6,C6,C6,C6,C6,E6,G6,G6,E6,C6,G6,G6,E6,G6,G6,E6,C6,C6,C6,G6,G6,E6,C6,G6,G6,G6,G6,G6,E6,C6,G6,G6,G6,G6,G6,E6,C6,G6,G6,G6,A6,G6,C7,G6,C7,G6,E6,D6,C6};
unsigned int b_music_term[49] = {1200,600,300,300,600,600,600,300,300,600,600,300,300,600,300,300,600,600,600,1200,600,600,600,600,600,600,1200,600,600,600,600,600,600,1200,600,600,600,600,300,300,300,300,1200,600,600,600,600,600,600};
unsigned char c_music[42] = {C6,C6,G6,G6,A6,A6,G6,F6,F6,E6,E6,D6,D6,C6,G6,G6,F6,F6,E6,E6,D6,G6,G6,F6,F6,E6,E6,D6,C6,C6,G6,G6,A6,A6,G6,F6,F6,E6,E6,D6,D6,C6};
unsigned int c_music_term[42] = {1200,600,600,600,600,600,600,1200,600,600,600,600,600,600,1200,600,600,600,600,600,600,1200,600,600,600,600,600,600,1200,600,600,600,600,600,600,1200,600,600,600,600,600,600};
unsigned char d_music[29] ={D6,E6,G6,G6,G6,G6,G6,G6,G6,D6,E6,G6,G6,G6,G6,G6,G6,D6,E6,G6,G6,G6,G6,G6,G6,G6,G6,F6S,F6S};
unsigned int d_music_term[29] ={1200,600,600,300,300,300,150,300,150,300,300,300,600,300,150,300,150,300,300,300,600,300,150,300,150,300,300,300,300};

unsigned char a_music_value = 0, b_music_value = 0, c_music_value = 0, d_music_value = 0;

//sound display off
unsigned char sound_flag = 1;
float sound_new = 0;
float sound_old = 0;
float sound_check = 0;
unsigned char sec2ms_flag = 0;


void User_Task1(void){
	MP3_init();
	while(1){
		Sound_Flag_Check();
		switch(sound_flag){
		case 0 :
			LCD_string(0x80|0x40, "                ");
			break;
		case 1 :
			MP3_sound_control();
			if(sec2ms_flag == 1){
				sec2ms = 0;
				sec2ms_flag = 0;
			}
			if(sec2ms >= 1000){
				sound_flag = 0;
			}
			break;
		}
		if (encoder_flag == 0) {
			MP3_music_control();
		}
		MP3_start_stop();
	}
}

// 초기화
void MP3_init(void){
	Initialize_LCD();
	HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_value, 1);
}

//sound display off
void Sound_Flag_Check(){
	sound_new = (100.0/4095.0)*(float)adc_value[0];
	sound_check = sound_old - sound_new;
	if(-5 > sound_check || sound_check > 5){
		sound_old = sound_new;
		sound_flag = 1;
		sec2ms_flag = 1;
	}
}

// 곡 선택
void MP3_music_control(void){
	ENC_Value = __HAL_TIM_GET_COUNTER(&htim4);
	if (ENC_Value>=15 || ENC_Value<2) {
		ENC_Value = 0;
	}
	else if (ENC_Value>=2 && ENC_Value<6) {
		ENC_Value = 4;
	}
	else if (ENC_Value>=6 && ENC_Value<10) {
		ENC_Value = 8;
	}
	else if (ENC_Value>=10 && ENC_Value<15) {
		ENC_Value = 12;
	}

	switch(ENC_Value){
	case 0:
		LCD_string(0x80|0x03, "Airplane   ");
		A_music();
		b_music_value = 0;
		c_music_value = 0;
		d_music_value = 0;
		break;
	case 4:
		LCD_string(0x80|0x03, "Three Bear ");
		B_music();
		a_music_value = 0;
		c_music_value = 0;
		d_music_value = 0;
		break;
	case 8:
		LCD_string(0x80|0x03, "Little Star");
		C_music();
		a_music_value = 0;
		b_music_value = 0;
		d_music_value = 0;
		break;
	case 12:
		LCD_string(0x80|0x03, "Baby Shark ");
		D_music();
		a_music_value = 0;
		b_music_value = 0;
		c_music_value = 0;
		break;
	}

}

// 비행기
void A_music(void){

	if (sec1ms>=a_music_term[a_music_value]) {
		TIM3->PSC = a_music[a_music_value];
		++a_music_value;
		sec1ms = 0;
		a_music_value %= 25;
		HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
	}
	if (sec1ms >= 50) {
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	}
}
// 곰세마리
void B_music(void){

	if (sec1ms>=b_music_term[b_music_value]) {
		TIM3->PSC = b_music[b_music_value];
		++b_music_value;
		sec1ms = 0;
		b_music_value %= 49;
		HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
	}
	if (sec1ms >= 50) {
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	}
}
// 반짝반짝 작은별
void C_music(void){

	if (sec1ms>=c_music_term[c_music_value]) {
		TIM3->PSC = c_music[c_music_value];
		++c_music_value;
		sec1ms = 0;
		c_music_value %= 42;
		HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
	}
	if (sec1ms >= 50) {
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	}
}
// 아기상어
void D_music(void){

	if (sec1ms>=d_music_term[d_music_value]) {
		TIM3->PSC = d_music[d_music_value];
		++d_music_value;
		sec1ms = 0;
		d_music_value %= 29;
		HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);
	}
	if (sec1ms >= 50) {
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	}
}

// start & stop
void MP3_start_stop(void){
	if (PA4_INT_Flag == 1) {
		encoder_flag = 1;
		LCD_string(0x80|0x03, "   STOP    ");
		HAL_TIM_Encoder_Stop(&htim4, TIM_CHANNEL_1);
		HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);

	}
	else if (PA4_INT_Flag >= 2) {
		PA4_INT_Flag = 0;
		encoder_flag = 0;
		I2C_LCD_Command(0x01);
		HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_1);
		HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	}
}

// 소리 조절
void MP3_sound_control(void){
	//   sound_flag = 1;
	sound_value = (100.0/4095.0)*(float)adc_value[0];
	if (sound_value < 10) {
		LCD_string(0x80|0x40, "                ");
		TIM3->CCR1 = 0;
	}
	else if (sound_value < 20) {
		LCD_string(0x80|0x40, "**              ");
		TIM3->CCR1 = 2;
	}
	else if (sound_value < 30) {
		LCD_string(0x80|0x40, "****            ");
		TIM3->CCR1 = 6;
	}
	else if (sound_value < 40) {
		LCD_string(0x80|0x40, "******          ");
		TIM3->CCR1 = 12;
	}
	else if (sound_value < 50) {
		LCD_string(0x80|0x40, "********        ");
		TIM3->CCR1 = 20;
	}
	else if (sound_value < 60) {
		LCD_string(0x80|0x40, "**********      ");
		TIM3->CCR1 = 30;
	}
	else if (sound_value < 70) {
		LCD_string(0x80|0x40, "************    ");
		TIM3->CCR1 = 42;
	}
	else if (sound_value < 80) {
		LCD_string(0x80|0x40, "**************  ");
		TIM3->CCR1 = 100;
	}
	else if (sound_value < 90) {
		LCD_string(0x80|0x40, "****************");
		TIM3->CCR1 = 500;
	}
}

// 버튼 클릭
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){

	if(GPIO_Pin == GPIO_PIN_4){
		new_tick_1 = sec3ms;
		sec3ms %= 60000;
	}
	if(new_tick_1 - old_tick_1 < 0){
		new_tick_1 = new_tick_1 + 60000;
	}
	if(GPIO_Pin==GPIO_PIN_4 && (new_tick_1 - old_tick_1 > 300)){
		++PA4_INT_Flag;
		old_tick_1 = new_tick_1;
	}
}




